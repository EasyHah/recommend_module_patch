# 工业园监控 · Fluent Final（抽屉 + FluentCard + 等分侧栏）\n\n运行：npm i && npm run dev\n

## 新增：地上/地下演示模块
- 访问路径：`/scene/gu`
- 数据：`public/data/geojson/*`
- 运行：`npm i` 后 `npm run dev`
